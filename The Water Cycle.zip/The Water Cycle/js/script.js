$(document).ready(function(){
	// --------------------------- Intro Page -------------------------------------
	$('.intro-button1').click(function(){
		$(".logo").addClass("move-me");
		$(".background").addClass("move-me");
		$(".start-btn").addClass("move-me");
		$(".move-screen").addClass("open");
		$(".open").show("move-me1");
		transition(".page-yourPageID1","push-left");
	});

	// --------------------------- Menu Page -------------------------------------

	$('.intro-button2').click(function(){
		transition(".page-yourPageID11","fade");
	});

	$('.intro-button3').click(function(){
		transition(".page-yourPageID14","fade");
	});
    
	$('.menu1-button').click(function(){
		transition(".page-yourPageID11","fade");
	});

	$('.menu2-button').click(function(){
		transition(".page-yourPageID2","fade");
	});

	$('.menu3-button').click(function(){
		transition(".page-yourPageID3","fade");
	});

	$('.p-menu-button').click(function(){
		transition(".page-intro","fade");
	});


    $('.p1-button').click(function(){
		transition(".page-yourPageID2","fade");
	});

	$('.p2-button').click(function(){
		transition(".page-yourPageID3","fade");
	});

	$('.p3-button').click(function(){
		transition(".page-yourPageID4","fade");
	});

	$('.p4-button').click(function(){
		transition(".page-yourPageID5","fade");
	});

	$('.p5-button').click(function(){
		transition(".page-yourPageID6","fade");
	});

	$('.p6-button').click(function(){
		transition(".page-yourPageID7","fade");
	});

	$('.p7-button').click(function(){
		transition(".page-yourPageID8","fade");
	});

	$('.p8-button').click(function(){
		transition(".page-yourPageID9","fade");
	});

	$('.p9-button').click(function(){
		transition(".page-yourPageID10","fade");
	});

	$('.p10-button').click(function(){
		transition(".page-yourPageID11","fade");
	});

	$('.p11-button').click(function(){
		transition(".page-yourPageID12","fade");
	});

	$('.p12-button').click(function(){
		transition(".page-yourPageID13","fade");
	});

	$('.p13-button').click(function(){
		transition(".page-yourPageID11","fade");
	});

	$('.p14-button').click(function(){
		transition(".page-yourPageID14","fade");
	});
		
	$('.p-quiz').click(function(){
		transition(".page-yourPageID14","fade");
	});

	$('.p-dnd').click(function(){
		transition(".page-yourPageID13","fade");
	});

	$(document).ready(function(){
	$('.drag-me').draggable({revert:"invalid", snap:".target"});
	$('.target').droppable({
      	drop: function( event, ui ) {
          itemsInPosition++;
          // get id of draggable and droppable id
          var draggableID = $(ui.draggable).attr("id");
          var droppableID = $(this).attr("id");
          if(draggableID[4]==droppableID[6]){
            console.log("correct")
            totalCorrect++;
          }
          testIfComplete();
      	}
    });

});




var itemsInPosition = 0;
var totalItems = 6;
var totalCorrect = 0;

function testIfComplete(){
  if(itemsInPosition==totalItems){
    alert("You got " + totalCorrect + " right")								
  }
}

$(document).ready(function(){
	$('#answer1').click(function(){
		$(this).addClass("selected");
		setTimeout(function() {
		    checkAnswer(1);
		},1000);
	});
	$('#answer2').click(function(){
		$(this).addClass("selected")
		setTimeout(function() {
		    checkAnswer(2);
		},1000);
	});
	$('#answer3').click(function(){
		$(this).addClass("selected")
		setTimeout(function() {
		    checkAnswer(3);
		},1000);
	});

	$('#next-btn').click(function(){
		nextQuestion();
	});
	nextQuestion();

});




var quizData = [
		{question:"The process where a Liquid turns into a Gas is called what?",
		 answers:["Surface Runoff","Evapouration","Condensation"],
		 correctAnswer:2,
		 feedback:"Evapouration is when a liquid and turns into a gas",
		 background:"images/q1-b.png",
		},
		 {question:"Snow, Sleet, Hail and rain of different types of which Water cycle process?",
		 answers:["Precipitation","Natural Rainfall","Transpiration"],
		 correctAnswer:1,
		 feedback:"Precipitation is any form of product that returns to the earths surface created by clouds",
		 background:"images/q2-b.png",
		},
		{question:"What is the movement through plants in the water cycle called?",
		 answers:["Transpiration","Transportation","Leaf Flow"],
		 correctAnswer:1,
		 feedback:"This can occur in trees and plants",
		 background:"images/q3-b.png",
		},
		{question:"When water DOESNT infiltrate the sufrace and runs along the ground, what is this called?",
		 answers:["Surface Runoff","Percolation","Standing water"],
		 correctAnswer:1,
		 feedback:"Urbanisation of cities allows surface runoff to occur",
		 background:"images/q4-b.png",
		},
		{question:"The movement of water in the water cycle is called?",
		 answers:["infiltration","Transpiration","Transportation"],
		 correctAnswer:3,
		 feedback:"Just like any for of transport, this can be related to water as well!.",
		 background:"images/q5-b.png",
		},
		{question:"when water sinks into the ground this is called??",
		 answers:["Sinking Water","Percolation","Infiltration"],
		 correctAnswer:3,
		 feedback: "Water that infiltrates the surfaceis called infiltration",
		 background:"images/q6-b.png",
		},
];


var currentQuestion = 0;
var totalQuestions = quizData.length;
var score = 0;

function showQuestion(){
	$(".quiz-image").attr("src",quizData[currentQuestion-1].background);
	$("#question").html(quizData[currentQuestion-1].question);
	$("#answer1").html(quizData[currentQuestion-1].answers[0]);
	$("#answer2").html(quizData[currentQuestion-1].answers[1]);
	$("#answer3").html(quizData[currentQuestion-1].answers[2]);
	$("#feedback").html(quizData[currentQuestion-1].feedback);
}

function nextQuestion(){
	currentQuestion++;

	if (currentQuestion==7){
		transition(".page-yourPageID19","fade");
	};
	
	
	showQuestion();
	
	// hide feedback and next button
	$("#next-btn").addClass("hidden");
	$("#feedback").addClass("hidden");
	// remove all incorrect, correct classes on answer buttons
	$('.answer-box').removeClass("correct incorrect");
}

function checkAnswer(selectedAnswer){
	var theCorrectAnswer = quizData[currentQuestion-1].correctAnswer;
	// remove the grey selected class
	$('.answer-box').removeClass("selected");

	// turn the boxes red or green depending on if they are the correct answer
	$( ".answer-box" ).each(function( index ) {
	  if((index+1)==theCorrectAnswer){
	  	$( this ).addClass("correct");
	  } else {
	  	$( this ).addClass("incorrect");
	  }
	});

	if(selectedAnswer==theCorrectAnswer){
		// got it correct
		score += 10;
		$(".score").html(score);
	} else {
		// got it wrong so do nothing
	}
	// show feedback and next button
	$("#next-btn").removeClass("hidden");
	$("#feedback").removeClass("hidden");
}

});

// --------------------------- Transition Pages -------------------------------------

/* use by:  transition(".page-menu","fade");

   pass in id of page to show next.  Type can be either "push-left", "push-right"
   or "fade" depending on the type of animation you want to happen.
   Classes are added to incoming and outgoing page that adds a CSS animation
   which moves them into position.  Listener is added for when animation
   is over to tidy up and remove the "current" class from the old page

   This code modified from Sitepoint book "Build Mobile websites and apps
   for Smart Devices", Castledine, Eftos, Wheeler (2011) */

function transition(toPage, type){
	var toPage = $(toPage),
    	fromPage = $(".pages .current"); // store the page that is currently showing

    toPage
    .addClass("current " + type + " in")
    .one("msAnimationEnd animationend oAnimationEnd", function(){  // listens for when the animation has finished
      fromPage.removeClass("current " + type + " out" );
      toPage.removeClass(type + " in");
    });
  fromPage.addClass(type + " out ");
}


